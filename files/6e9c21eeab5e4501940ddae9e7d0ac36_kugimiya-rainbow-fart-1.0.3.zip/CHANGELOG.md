# Changelog

## [1.0.3](https://github.com/zthxxx/kugimiya-rainbow-fart/compare/v1.0.2...v1.0.3) (2020-10-08)

### fix

* fix issues of 'voices/filename' typo ([eb1d1f1](https://github.com/zthxxx/kugimiya-rainbow-fart/commit/eb1d1f1ac2f2ec8dfa5849604ba1fc97b5b92868(type:fix)))

### chore

* **deps-dev:** bump @actions/core from 1.2.4 to 1.2.6 ([0db407f](https://github.com/zthxxx/kugimiya-rainbow-fart/commit/0db407f52ff9e32d162ff2bd53cc5b4d1caf202b(type:chore)))


## [1.0.1](https://github.com/zthxxx/kugimiya-rainbow-fart/compare/v1.0.0...v1.0.1) (2020-06-29)


### docs

* update docs and typo keywords ([5ff4187](https://github.com/zthxxx/kugimiya-rainbow-fart/commit/5ff41873d6463106fbc8112b75075ecae3373987(type:docs)))


### ci

* add release action ([8ddf48e](https://github.com/zthxxx/kugimiya-rainbow-fart/commit/8ddf48ed6009b7d9f7dc8ced828c5fc4d6335290(type:ci)))
* init github action for build ([098ef33](https://github.com/zthxxx/kugimiya-rainbow-fart/commit/098ef3388266600c22117b28411ab80ad7b6cfa1(type:ci)))

## [1.0.0](https://github.com/zthxxx/kugimiya-rainbow-fart/compare/v0.0.1...v1.0.0) (2020-06-25)

- update all of voices
- split the keywords config
- optimize keywords-voices map
- add building process

## [0.0.1](https://github.com/zthxxx/kugimiya-rainbow-fart/tree/v0.0.1) (2020-06-21)

- init Kugimiya voice package
